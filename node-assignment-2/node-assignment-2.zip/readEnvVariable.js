/* require('dotenv').config();
console.log(process.env.GREET);
console.log(process.env.NAME); 
 */

console.log("Hello", process.env.username);