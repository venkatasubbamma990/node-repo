let greet = "Hello";
let myname = process.argv[2];
console.log(greet,myname)
//hello Ravi