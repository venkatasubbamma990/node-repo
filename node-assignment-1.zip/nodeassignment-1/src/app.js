let imported = require('../src/index');
//console.log(imported);
imported.read();
imported.write();
imported.update();
imported.deleted();